"""Универсальный Telegram-бот: отправь ссылку, получи видео.

Стек (всё бесплатное, open source): aiogram 3, yt-dlp, ffmpeg.
"""
import asyncio
import json
import logging
import os
import re
import shutil
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path

import yt_dlp
from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.client.telegram import TelegramAPIServer
from aiogram.filters import CommandStart
from aiogram.types import (
    CallbackQuery,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("bot")

# ---------------------------------------------------------------- настройки
BOT_TOKEN = os.environ["BOT_TOKEN"]
LOCAL_API_URL = os.getenv("LOCAL_API_URL", "").strip()  # напр. http://telegram-bot-api:8081
COOKIES_FILE = os.getenv("COOKIES_FILE", "cookies.txt")  # необязательно (Instagram, возрастные ролики)
TMP_ROOT = Path(os.getenv("TMP_DIR", "/tmp/tgbot"))
MAX_PARALLEL = int(os.getenv("MAX_PARALLEL", "2"))
JOB_TTL = 20 * 60  # сколько секунд хранить файл, если ждём выбор пользователя

# Облачный Bot API: до 50 МБ. Локальный (бесплатный, open source): до 2000 МБ.
LIMIT = (1990 if LOCAL_API_URL else 49) * 1024 * 1024
LIMIT_MB = LIMIT // (1024 * 1024)

URL_RE = re.compile(r"https?://[^\s<>\"']+")
SEM = asyncio.Semaphore(MAX_PARALLEL)
router = Router()


class UserError(Exception):
    """Ошибка, текст которой можно показать пользователю."""


@dataclass
class Job:
    path: Path
    workdir: Path
    chat_id: int
    title: str = ""
    ts: float = field(default_factory=time.time)


JOBS: dict[str, Job] = {}


# ---------------------------------------------------------------- скачивание
@dataclass
class Downloaded:
    path: Path
    title: str


def _download(url: str, workdir: Path) -> Downloaded:
    opts = {
        "outtmpl": str(workdir / "%(id)s.%(ext)s"),
        # Лучшее видео + лучшее аудио; при равном разрешении/FPS предпочитаем H.264/AAC,
        # чтобы файл проигрывался в Telegram без перекодирования.
        "format": "bv*+ba/b",
        "format_sort": ["res", "fps", "vcodec:h264", "acodec:aac"],
        "merge_output_format": "mp4",  # только склейка потоков, без перекодирования
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "retries": 3,
        "fragment_retries": 3,
        "concurrent_fragment_downloads": 4,
    }
    if COOKIES_FILE and Path(COOKIES_FILE).is_file():
        opts["cookiefile"] = COOKIES_FILE
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
    except yt_dlp.utils.DownloadError as e:
        raise UserError(_explain(str(e))) from e
    if info.get("_type") == "playlist" and info.get("entries"):
        info = info["entries"][0]
    files = info.get("requested_downloads") or []
    path = Path(files[0]["filepath"]) if files else None
    if not path or not path.is_file():
        raise UserError("Не удалось получить видеофайл по этой ссылке.")
    return Downloaded(path=path, title=(info.get("title") or "").strip())


def _explain(msg: str) -> str:
    m = msg.lower()
    if "unsupported url" in m:
        return "Эта ссылка не поддерживается или в ней нет видео."
    if any(k in m for k in ("private", "login", "log in", "sign in", "cookies", "authentication")):
        return ("Видео закрыто или требует входа в аккаунт, поэтому скачать его нельзя. "
                "Если оно публичное — владелец бота может добавить cookies (см. README).")
    if any(k in m for k in ("not available", "unavailable", "removed", "deleted", "does not exist")):
        return "Видео недоступно: оно удалено, скрыто или ограничено в регионе сервера."
    if "age" in m and "restrict" in m:
        return "Видео с возрастным ограничением — без cookies аккаунта скачать нельзя."
    if "live" in m and "stream" in m:
        return "Это прямая трансляция — скачать её можно только после окончания."
    if any(k in m for k in ("429", "too many requests", "rate")):
        return "Платформа временно ограничила запросы. Попробуйте через несколько минут."
    return "Не удалось скачать видео: платформа отказала в доступе или изменила формат ссылки."


# ---------------------------------------------------------------- ffprobe / ffmpeg
@dataclass
class Meta:
    vcodec: str
    width: int
    height: int
    duration: float


async def _run(*cmd: str) -> tuple[int, str]:
    p = await asyncio.create_subprocess_exec(
        *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT
    )
    out, _ = await p.communicate()
    return p.returncode, out.decode(errors="replace")


async def probe(path: Path) -> Meta:
    code, out = await _run(
        "ffprobe", "-v", "error", "-print_format", "json", "-show_streams", "-show_format", str(path)
    )
    if code != 0:
        raise UserError("Скачанный файл повреждён или не является видео.")
    data = json.loads(out)
    v = next((s for s in data.get("streams", []) if s.get("codec_type") == "video"), None)
    if not v:
        raise UserError("В скачанном файле нет видеодорожки.")
    dur = float(data.get("format", {}).get("duration") or v.get("duration") or 0)
    return Meta(v.get("codec_name", ""), int(v.get("width", 0)), int(v.get("height", 0)), dur)


async def compress(src: Path, dst: Path, duration: float) -> None:
    """Перекодировать в H.264/AAC так, чтобы уложиться в лимит Telegram."""
    if duration <= 0:
        raise UserError("Не удалось определить длительность видео для сжатия.")
    total_bps = LIMIT * 0.92 * 8 / duration
    vb = int(total_bps - 128_000)
    if vb < 150_000:
        raise UserError(f"Видео слишком длинное, чтобы уместиться в {LIMIT_MB} МБ с приемлемым качеством.")
    height = 2160 if vb > 8_000_000 else 1440 if vb > 5_000_000 else 1080 if vb > 2_500_000 \
        else 720 if vb > 1_000_000 else 480
    code, out = await _run(
        "ffmpeg", "-y", "-i", str(src),
        "-c:v", "libx264", "-preset", "medium",
        "-b:v", str(vb), "-maxrate", str(int(vb * 1.2)), "-bufsize", str(vb * 2),
        "-vf", f"scale=-2:'min(ih,{height})'", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(dst),
    )
    if code != 0 or not dst.is_file():
        log.error("ffmpeg failed: %s", out[-800:])
        raise UserError("Не удалось сжать видео.")


# ---------------------------------------------------------------- отправка
def _mb(n: int) -> str:
    return f"{n / 1024 / 1024:.0f}"


def _kb(job_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text=f"Сжать для Telegram (до {LIMIT_MB} МБ)", callback_data=f"opt:{job_id}")
    ]])


async def deliver(m: Message, d: Downloaded, meta: Meta, workdir: Path) -> bool:
    """Отправляет результат. Возвращает True, если файл нужно сохранить для кнопки."""
    size = d.path.stat().st_size
    caption = d.title[:200] or None

    if size > LIMIT:
        job_id = uuid.uuid4().hex[:12]
        JOBS[job_id] = Job(d.path, workdir, m.chat.id, d.title)
        await m.answer(
            f"Видео в лучшем качестве ({meta.width}×{meta.height}, {_mb(size)} МБ) "
            f"больше лимита Telegram ({LIMIT_MB} МБ). Могу сделать сжатую версию.",
            reply_markup=_kb(job_id),
        )
        return True

    if meta.vcodec in {"h264", "hevc"}:
        await m.answer_video(
            FSInputFile(d.path), caption=caption, supports_streaming=True,
            width=meta.width, height=meta.height, duration=int(meta.duration),
        )
        return False

    # VP9/AV1 в оригинальном качестве: Telegram не всегда проигрывает их в чате.
    job_id = uuid.uuid4().hex[:12]
    JOBS[job_id] = Job(d.path, workdir, m.chat.id, d.title)
    await m.answer_document(
        FSInputFile(d.path), caption=(caption + "\n\n" if caption else "") +
        f"Оригинал без перекодирования ({meta.vcodec.upper()}, {meta.width}×{meta.height}) — отправлен файлом.",
        reply_markup=_kb(job_id),
    )
    return True


async def process_url(m: Message, url: str) -> None:
    status = await m.answer("⏳ Скачиваю…")
    workdir = TMP_ROOT / uuid.uuid4().hex
    workdir.mkdir(parents=True, exist_ok=True)
    keep = False
    error_shown = False
    try:
        await m.bot.send_chat_action(m.chat.id, "upload_video")
        async with SEM:
            d = await asyncio.to_thread(_download, url, workdir)
        meta = await probe(d.path)
        await status.edit_text("📤 Отправляю…")
        keep = await deliver(m, d, meta, workdir)
    except UserError as e:
        await status.edit_text(f"❌ {e}")
        error_shown = True
    except Exception:
        log.exception("process_url failed for %s", url)
        await status.edit_text("❌ Что-то пошло не так. Попробуйте ещё раз чуть позже.")
        error_shown = True
    finally:
        if not keep:
            shutil.rmtree(workdir, ignore_errors=True)
        if not error_shown:
            try:
                await status.delete()
            except Exception:
                pass


# ---------------------------------------------------------------- хендлеры
@router.message(CommandStart())
async def start(m: Message) -> None:
    await m.answer("Пришлите ссылку на видео (YouTube, TikTok, Instagram и др.) — верну готовый файл.")


@router.callback_query(F.data.startswith("opt:"))
async def on_optimize(cb: CallbackQuery) -> None:
    job = JOBS.pop(cb.data.split(":", 1)[1], None)
    if not job or not job.path.is_file():
        await cb.answer("Файл уже удалён, отправьте ссылку заново.", show_alert=True)
        return
    await cb.answer()
    await cb.message.edit_reply_markup(reply_markup=None)
    status = await cb.message.answer("⏳ Сжимаю…")
    try:
        meta = await probe(job.path)
        out = job.workdir / "optimized.mp4"
        async with SEM:
            await compress(job.path, out, meta.duration)
        m2 = await probe(out)
        await cb.message.answer_video(
            FSInputFile(out), caption=job.title[:200] or None, supports_streaming=True,
            width=m2.width, height=m2.height, duration=int(m2.duration),
        )
        await status.delete()
    except UserError as e:
        await status.edit_text(f"❌ {e}")
    except Exception:
        log.exception("optimize failed")
        await status.edit_text("❌ Не удалось подготовить сжатую версию.")
    finally:
        shutil.rmtree(job.workdir, ignore_errors=True)


@router.message(F.text)
async def on_text(m: Message) -> None:
    urls = URL_RE.findall(m.text)[:3]
    if not urls:
        await m.answer("Пришлите ссылку на видео.")
        return
    for u in urls:
        await process_url(m, u)


@router.message()
async def on_other(m: Message) -> None:
    await m.answer("Пока я умею скачивать видео по ссылкам. Пришлите ссылку.")


# ---------------------------------------------------------------- уборка и запуск
async def janitor() -> None:
    """Удаляет протухшие задачи и забытые временные папки."""
    while True:
        await asyncio.sleep(60)
        now = time.time()
        for jid, job in list(JOBS.items()):
            if now - job.ts > JOB_TTL:
                JOBS.pop(jid, None)
                shutil.rmtree(job.workdir, ignore_errors=True)
        if TMP_ROOT.exists():
            for p in TMP_ROOT.iterdir():
                if p.is_dir() and now - p.stat().st_mtime > JOB_TTL * 3:
                    shutil.rmtree(p, ignore_errors=True)


async def main() -> None:
    shutil.rmtree(TMP_ROOT, ignore_errors=True)
    TMP_ROOT.mkdir(parents=True, exist_ok=True)
    if LOCAL_API_URL:
        session = AiohttpSession(api=TelegramAPIServer.from_base(LOCAL_API_URL, is_local=True), timeout=3600)
    else:
        session = AiohttpSession(timeout=600)
    bot = Bot(BOT_TOKEN, session=session)
    dp = Dispatcher()
    dp.include_router(router)
    asyncio.create_task(janitor())
    log.info("Bot started. Upload limit: %d MB", LIMIT_MB)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
